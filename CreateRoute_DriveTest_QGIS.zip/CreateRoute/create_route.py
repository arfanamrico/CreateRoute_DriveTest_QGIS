from qgis.PyQt.QtWidgets import QAction, QDialog, QVBoxLayout, QFormLayout, QLineEdit, QPushButton, QComboBox, QDoubleSpinBox, QColorDialog, QCheckBox, QFileDialog, QLabel, QMessageBox, QHBoxLayout
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtCore import Qt, QVariant, QPointF
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY, QgsField,
    QgsLineSymbol, QgsSingleSymbolRenderer, QgsWkbTypes, QgsDistanceArea, QgsUnitTypes,
    QgsMarkerLineSymbolLayer, QgsMarkerSymbol,
    QgsCoordinateReferenceSystem, QgsCoordinateTransform
)
from qgis.gui import QgsMapTool, QgsRubberBand
from qgis.PyQt.QtCore import pyqtSignal
import math, os, json, urllib.request, urllib.error, xml.etree.ElementTree as ET
from qgis.PyQt.QtGui import QIcon

# Public OSRM demo server. NOTE: this is officially for light/testing use
# only (see https://project-osrm.org/#hosted-osrm-demo-server) -- for
# regular production use, self-host OSRM or switch to a service like
# OpenRouteService with your own API key.
OSRM_BASE_URL = "https://router.project-osrm.org/route/v1/driving/"

class RouteTool(QgsMapTool):
    finished = pyqtSignal(object)
    def __init__(self, canvas):
        super().__init__(canvas)
        self.canvas = canvas
        self.points = []
        self.rb = QgsRubberBand(canvas, QgsWkbTypes.LineGeometry)
        self.rb.setColor(QColor("red"))
        self.rb.setWidth(3)

    def canvasReleaseEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.points.append(self.toMapCoordinates(e.pos()))
            self._update()
        elif e.button() == Qt.RightButton:
            if len(self.points) >= 2:
                pts = self.points[:]
                self.points.clear()
                self.rb.reset(QgsWkbTypes.LineGeometry)
                self.finished.emit(pts)

    def canvasDoubleClickEvent(self, e):
        if len(self.points) >= 2:
            pts = self.points[:]
            self.points.clear()
            self.rb.reset(QgsWkbTypes.LineGeometry)
            self.finished.emit(pts)

    def _update(self):
        if len(self.points) > 1:
            self.rb.setToGeometry(QgsGeometry.fromPolylineXY(self.points), None)

    def reset(self):
        self.points.clear()
        self.rb.reset(QgsWkbTypes.LineGeometry)

class CreateRoute:
    def __init__(self, iface):
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.action = None
        self.tool = None
        self.layer = None
        self.dialog = None
        self.routes = []

    def initGui(self):
        plugin_dir = os.path.dirname(__file__)
        icon_path = os.path.join(plugin_dir, "icon.png")
        self.action = QAction(QIcon(icon_path),"Create Route – Drive Test", self.iface.mainWindow())
        self.action.triggered.connect(self.show_dialog)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Create Route – Drive Test", self.action)

    def unload(self):
        if self.action:
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginMenu("&Create Route – Drive Test", self.action)

    def show_dialog(self):
        if self.dialog is None:
            self.dialog = QDialog(self.iface.mainWindow())
            self.dialog.setWindowTitle("Create Route – Drive Test")
            self.dialog.resize(430, 520)
            root = QVBoxLayout(self.dialog)
            form = QFormLayout()

            self.route_id = QLineEdit("ROUTE_001")
            form.addRow("Route ID", self.route_id)

            self.style = QComboBox()
            self.style.addItems(["Solid", "Dashed", "Dotted", "Dash Dot", "Solid + Arrow", "Dashed + Arrow", "Arrow Only"])
            form.addRow("Line Style", self.style)

            self.color_btn = QPushButton("Choose Color")
            self.color = QColor("#ff0000")
            self.color_btn.setStyleSheet("background:#ff0000; color:white;")
            self.color_btn.clicked.connect(self.choose_color)
            form.addRow("Line Color", self.color_btn)

            self.width = QDoubleSpinBox()
            self.width.setRange(0.1, 20.0)
            self.width.setValue(2.5)
            self.width.setSingleStep(0.5)
            form.addRow("Line Width", self.width)

            self.arrow_check = QCheckBox("Show repeated direction arrows")
            self.arrow_check.setChecked(True)
            form.addRow("", self.arrow_check)

            self.arrow_spacing = QDoubleSpinBox()
            self.arrow_spacing.setRange(10, 100000)
            self.arrow_spacing.setValue(500)
            self.arrow_spacing.setSuffix(" m")
            form.addRow("Arrow Spacing", self.arrow_spacing)

            self.arrow_size = QDoubleSpinBox()
            self.arrow_size.setRange(1, 20)
            self.arrow_size.setValue(5)
            self.arrow_size.setSuffix(" mm")
            form.addRow("Arrow Size", self.arrow_size)

            self.start_end = QCheckBox("Add START / END markers")
            self.start_end.setChecked(True)
            form.addRow("", self.start_end)

            self.snap_road = QCheckBox("Snap to road (online, OSRM)")
            self.snap_road.setChecked(False)
            form.addRow("", self.snap_road)
            snap_note = QLabel(
                "Requires internet. Uses the public OSRM demo server "
                "(light/testing use only, per its usage policy)."
            )
            snap_note.setWordWrap(True)
            snap_note.setStyleSheet("color: gray; font-size: 10px;")
            form.addRow("", snap_note)

            self.output = QComboBox()
            self.output.addItems(["TAB", "KML"])
            form.addRow("Output Format", self.output)

            self.path = QLineEdit()
            browse = QPushButton("Browse")
            browse.clicked.connect(self.browse_output)
            row = QHBoxLayout()
            row.addWidget(self.path); row.addWidget(browse)
            form.addRow("Output File", row)

            root.addLayout(form)
            info = QLabel("Left-click: add points • Double-click or Right-click: finish route")
            info.setWordWrap(True)
            root.addWidget(info)

            create = QPushButton("CREATE ROUTE")
            create.clicked.connect(self.start_route)
            root.addWidget(create)

            clear = QPushButton("Clear")
            clear.clicked.connect(self.clear_routes)
            root.addWidget(clear)

        self.dialog.show()
        self.dialog.raise_()

    def choose_color(self):
        c = QColorDialog.getColor(self.color, self.dialog, "Choose route color")
        if c.isValid():
            self.color = c
            self.color_btn.setStyleSheet(f"background:{c.name()}; color:white;")

    def browse_output(self):
        ext = self.output.currentText().lower()
        path, _ = QFileDialog.getSaveFileName(self.dialog, "Save route", "", f"{ext.upper()} (*.{ext})")
        if path:
            self.path.setText(path)

    def start_route(self):
        if self.tool:
            self.canvas.unsetMapTool(self.tool)
        self.tool = RouteTool(self.canvas)
        self.tool.rb.setColor(self.color)
        self.tool.rb.setWidth(max(1, int(self.width.value())))
        self.tool.finished.connect(self.route_finished)
        self.canvas.setMapTool(self.tool)
        self.dialog.hide()

    def route_finished(self, points):
        if len(points) < 2:
            return

        if self.snap_road.isChecked():
            snapped = self._snap_to_road(points)
            if snapped is not None:
                points = snapped
            # if snapping failed, _snap_to_road already warned the user
            # and we fall back to the straight line the user drew

        self._ensure_layer()
        feat = QgsFeature(self.layer.fields())
        geom = QgsGeometry.fromPolylineXY(points)
        feat.setGeometry(geom)

        rid = self.route_id.text().strip() or f"ROUTE_{len(self.routes)+1:03d}"
        dist = QgsDistanceArea()
        dist.setSourceCrs(self.layer.crs(), QgsProject.instance().transformContext())
        # Without an explicit ellipsoid, measureLength() just sums planar
        # (straight-line) distances in the layer's CRS units, which is
        # NOT the same as true ground distance -- especially on geographic
        # CRSs (degrees) or distorted projections like Web Mercator
        # (EPSG:3857). QGIS's built-in "Measure Line" tool defaults to
        # ellipsoidal/geodesic calculation using the project's configured
        # ellipsoid, so we match that here to get consistent numbers.
        dist.setEllipsoid(QgsProject.instance().ellipsoid())
        distance = dist.measureLength(geom)
        distance = dist.convertLengthMeasurement(distance, QgsUnitTypes.DistanceMeters)

        az = self._azimuth(points[0], points[1])
        feat["route_id"] = rid
        feat["distance_m"] = distance
        feat["direction"] = az
        feat["style"] = self.style.currentText()
        self.layer.dataProvider().addFeature(feat)
        self.layer.updateExtents()
        self.layer.triggerRepaint()
        QgsProject.instance().addMapLayer(self.layer) if self.layer.id() not in [x.id() for x in QgsProject.instance().mapLayers().values()] else None
        self.routes.append(points)

        self._apply_symbol()
        self._export_if_requested()
        self.route_id.setText(f"ROUTE_{len(self.routes)+1:03d}")
        self.show_dialog()

    def _snap_to_road(self, points):
        """
        Sends the clicked waypoints (in canvas CRS) to OSRM and returns a
        new list of QgsPointXY (still in canvas CRS) following the actual
        road network through those waypoints, in order. Returns None on
        any failure (no internet, no route found, etc.) after warning the
        user, so the caller can fall back to the straight-line route.
        """
        canvas_crs = self.canvas.mapSettings().destinationCrs()
        wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
        to_wgs84 = QgsCoordinateTransform(canvas_crs, wgs84, QgsProject.instance())
        from_wgs84 = QgsCoordinateTransform(wgs84, canvas_crs, QgsProject.instance())

        try:
            lonlat_points = [to_wgs84.transform(p) for p in points]
        except Exception as e:
            QMessageBox.warning(self.dialog, "Snap to road",
                                 f"Gagal transformasi koordinat.\n{e}")
            return None

        coord_str = ";".join(f"{p.x()},{p.y()}" for p in lonlat_points)
        url = f"{OSRM_BASE_URL}{coord_str}?overview=full&geometries=geojson"

        try:
            with urllib.request.urlopen(url, timeout=15) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except urllib.error.URLError as e:
            QMessageBox.warning(self.dialog, "Snap to road",
                                 f"Tidak bisa menghubungi OSRM (cek koneksi internet).\n{e}")
            return None
        except Exception as e:
            QMessageBox.warning(self.dialog, "Snap to road", f"Request OSRM gagal.\n{e}")
            return None

        if data.get("code") != "Ok" or not data.get("routes"):
            QMessageBox.warning(self.dialog, "Snap to road",
                                 f"OSRM tidak menemukan rute jalan untuk titik-titik ini "
                                 f"(code: {data.get('code')}). Menggunakan garis lurus.")
            return None

        coords_lonlat = data["routes"][0]["geometry"]["coordinates"]
        try:
            return [from_wgs84.transform(QgsPointXY(lon, lat)) for lon, lat in coords_lonlat]
        except Exception as e:
            QMessageBox.warning(self.dialog, "Snap to road",
                                 f"Gagal transformasi hasil OSRM kembali ke CRS project.\n{e}")
            return None

    def _ensure_layer(self):
        if self.layer is not None:
            try:
                # isValid() itself raises RuntimeError if the underlying
                # C++ QgsVectorLayer was already destroyed (e.g. the user
                # removed "Drive Test Routes" from the Layers panel, or
                # closed/switched the QGIS project).
                still_valid = self.layer.isValid()
                still_in_project = self.layer.id() in QgsProject.instance().mapLayers()
            except RuntimeError:
                still_valid = False
                still_in_project = False
            if still_valid and still_in_project:
                return
            # stale reference -> drop it so a fresh layer gets created below
            self.layer = None

        crs = self.canvas.mapSettings().destinationCrs().authid()
        self.layer = QgsVectorLayer(f"LineString?crs={crs}", "Drive Test Routes", "memory")
        p = self.layer.dataProvider()
        p.addAttributes([
            QgsField("route_id", QVariant.String, len=50),
            QgsField("distance_m", QVariant.Double),
            QgsField("direction", QVariant.Double),
            QgsField("style", QVariant.String, len=50)
        ])
        self.layer.updateFields()

    def _azimuth(self, a, b):
        dx = b.x() - a.x(); dy = b.y() - a.y()
        return (math.degrees(math.atan2(dx, dy)) + 360) % 360

    def _apply_symbol(self):
        """
        Rebuilds the line renderer for the current style choice.

        FIX 1: setCustomDashVector() alone does nothing in QGIS unless
        setUseCustomDashPattern(True) is also set on the same symbol layer.
        FIX 2: none of the "+ Arrow" / "Arrow Only" styles ever added an
        arrow symbol. A proper arrowhead needs a *marker line* symbol
        layer (QgsMarkerLineSymbolLayer) stacked on top of the base line,
        placed at a fixed interval and rotated to follow the line's
        direction. That's what was missing.
        """
        if not self.layer:
            return

        style = self.style.currentText()
        symbol = QgsLineSymbol.createSimple({"color": self.color.name(), "width": str(self.width.value())})
        line_layer = symbol.symbolLayer(0)

        # --- dash pattern (must explicitly enable custom dash) ---
        if style in ("Dashed", "Dashed + Arrow"):
            line_layer.setCustomDashVector([4, 3])
            line_layer.setUseCustomDashPattern(True)
        elif style == "Dotted":
            line_layer.setCustomDashVector([1, 3])
            line_layer.setUseCustomDashPattern(True)
        elif style == "Dash Dot":
            line_layer.setCustomDashVector([4, 2, 1, 2])
            line_layer.setUseCustomDashPattern(True)
        elif style == "Arrow Only":
            # no visible base line, arrows only
            line_layer.setPenStyle(Qt.NoPen)

        # --- repeated direction arrows ---
        needs_arrow = style in ("Solid + Arrow", "Dashed + Arrow", "Arrow Only")
        if needs_arrow and self.arrow_check.isChecked():
            arrow_symbol = QgsMarkerSymbol.createSimple({
                "name": "filled_arrowhead",
                "color": self.color.name(),
                "outline_color": self.color.name(),
                "size": str(self.arrow_size.value()),
                "size_unit": "MM",
                "angle": "0",
            })
            marker_line = QgsMarkerLineSymbolLayer(True)  # rotateMarker=True -> follows line direction
            marker_line.setSubSymbol(arrow_symbol)
            marker_line.setPlacement(QgsMarkerLineSymbolLayer.Interval)
            marker_line.setInterval(self.arrow_spacing.value())
            # RenderMapUnits would treat the interval as raw CRS units
            # (degrees on a geographic CRS, or distorted "meters" on
            # something like Web Mercator) -- on a geographic CRS a
            # value of "10" means 10 degrees, which is far longer than
            # any route, so only the very first arrow (always placed at
            # the start) ever showed up. RenderMetersInMapUnits converts
            # true meters to the correct map-unit distance using the
            # project's ellipsoid, matching what "10 m" actually means.
            marker_line.setIntervalUnit(QgsUnitTypes.RenderMetersInMapUnits)
            symbol.appendSymbolLayer(marker_line)

        self.layer.setRenderer(QgsSingleSymbolRenderer(symbol))
        self.layer.triggerRepaint()

    def _export_if_requested(self):
        path = self.path.text().strip()
        if not path:
            return
        if self.output.currentText() == "TAB":
            self._export_tab(path)
        else:
            self._export_kml(path)

    def _export_tab(self, path):
        try:
            import processing
            processing.run("native:savefeatures", {"INPUT": self.layer, "OUTPUT": path})
        except Exception as e:
            QMessageBox.warning(self.dialog, "TAB export", f"Gagal export TAB.\n{e}")

    def _export_kml(self, path):
        root = ET.Element("kml", {"xmlns":"http://www.opengis.net/kml/2.2"})
        doc = ET.SubElement(root, "Document")
        style = ET.SubElement(doc, "Style", {"id":"routeStyle"})
        ls = ET.SubElement(style, "LineStyle")
        ET.SubElement(ls, "color").text = self._kml_color(self.color)
        ET.SubElement(ls, "width").text = str(self.width.value())

        # KML/Google Earth has no equivalent of QGIS's "marker line"
        # symbology (repeated arrows along a line), so for any style that
        # needs arrows we simulate them as individual rotated icon
        # Placemarks spaced along the route.
        arrow_styles = {"Solid + Arrow", "Dashed + Arrow", "Arrow Only"}

        for f in self.layer.getFeatures():
            geom = f.geometry()
            if geom.isEmpty(): continue
            pm = ET.SubElement(doc, "Placemark")
            ET.SubElement(pm, "name").text = str(f["route_id"])
            ET.SubElement(pm, "styleUrl").text = "#routeStyle"
            line = ET.SubElement(ET.SubElement(pm, "LineString"), "coordinates")
            pts = geom.asPolyline()
            line.text = " ".join(f"{p.x()},{p.y()},0" for p in pts)

            feat_style = str(f["style"]) if f["style"] else ""
            if feat_style in arrow_styles and self.arrow_check.isChecked():
                self._add_kml_arrows(doc, geom, str(f["route_id"]))

        ET.ElementTree(root).write(path, encoding="utf-8", xml_declaration=True)

    def _add_kml_arrows(self, doc, geom, route_id):
        """
        Places rotated arrow-icon Placemarks along `geom` every
        `arrow_spacing` real-world meters, mimicking the QGIS marker-line
        arrows so they're also visible when the KML is opened in Google
        Earth.
        """
        length_map_units = geom.length()
        if length_map_units <= 0:
            return

        dist_calc = QgsDistanceArea()
        dist_calc.setSourceCrs(self.layer.crs(), QgsProject.instance().transformContext())
        dist_calc.setEllipsoid(QgsProject.instance().ellipsoid())
        length_m = dist_calc.convertLengthMeasurement(dist_calc.measureLength(geom), QgsUnitTypes.DistanceMeters)
        if length_m <= 0:
            return

        # map units per meter for this specific route/CRS -- same
        # conversion logic used for the on-canvas arrow spacing fix.
        scale = length_map_units / length_m
        step = self.arrow_spacing.value() * scale
        if step <= 0:
            return

        idx = 0
        d = step
        while d < length_map_units:
            p1 = geom.interpolate(d).asPoint()
            ahead = min(d + max(step * 0.05, length_map_units * 1e-6), length_map_units)
            p2 = geom.interpolate(ahead).asPoint()
            heading = self._azimuth(p1, p2)
            # Google's default "arrow.png" icon does NOT face north at
            # heading=0 like the KML spec's usual convention -- its
            # baked-in artwork faces the opposite way, so the rotation
            # comes out reversed unless we correct for it here.
            heading = (heading + 180.0) % 360.0

            pm = ET.SubElement(doc, "Placemark")
            ET.SubElement(pm, "name").text = f"{route_id}_arrow_{idx}"
            pm_style = ET.SubElement(pm, "Style")
            icon_style = ET.SubElement(pm_style, "IconStyle")
            ET.SubElement(icon_style, "color").text = self._kml_color(self.color)
            ET.SubElement(icon_style, "scale").text = "0.6"
            ET.SubElement(icon_style, "heading").text = f"{heading:.1f}"
            icon = ET.SubElement(icon_style, "Icon")
            ET.SubElement(icon, "href").text = "http://maps.google.com/mapfiles/kml/shapes/arrow.png"
            # scale=0 hides the on-map text label next to the icon while
            # keeping <name> intact for the Places panel / attribute list.
            label_style = ET.SubElement(pm_style, "LabelStyle")
            ET.SubElement(label_style, "scale").text = "0"
            point = ET.SubElement(pm, "Point")
            ET.SubElement(point, "coordinates").text = f"{p1.x()},{p1.y()},0"

            idx += 1
            d += step

    def _kml_color(self, c):
        return f"ff{c.blue():02x}{c.green():02x}{c.red():02x}"

    def clear_routes(self):
        if self.tool:
            self.tool.reset()
        if self.layer:
            self.layer.dataProvider().truncate()
            self.layer.updateExtents()
            self.layer.triggerRepaint()
        self.routes = []
        self.route_id.setText("ROUTE_001")