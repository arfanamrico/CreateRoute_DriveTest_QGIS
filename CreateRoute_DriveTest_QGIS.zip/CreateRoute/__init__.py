def classFactory(iface):
    from .create_route import CreateRoute
    return CreateRoute(iface)
